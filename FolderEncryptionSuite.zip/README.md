# Folder Encryption Suite

A secure application for encrypting and protecting folders with password-based encryption and 7z archive protection.

## Features

- Encrypt folders with strong AES-256 encryption
- Password-based key derivation for secure encryption
- Progress tracking during encryption and decryption operations
- 7z archive protection for additional security
- Modern graphical user interface

## Running the Application

### Option 1: Using the Batch File (Recommended for Windows Users)

1. Make sure you have Python 3.6+ installed on your system
2. Install the required dependencies:
   ```
   pip install cryptography py7zr tkinter
   ```
3. Double-click the `run_folder_encryption.bat` file to start the application

### Option 2: Running Directly with Python

1. Make sure you have Python 3.6+ installed on your system
2. Install the required dependencies:
   ```
   pip install cryptography py7zr tkinter
   ```
3. Run the application:
   ```
   python main.py
   ```

## Creating an Executable (For Distribution)

If you want to create a standalone executable that doesn't require Python to be installed:

1. Install PyInstaller:
   ```
   pip install pyinstaller
   ```

2. Create the executable:
   ```
   pyinstaller --onefile --windowed --icon=app_icon.ico --name="FolderEncryptor" main.py
   ```

3. The executable will be created in the `dist` folder

Note: Some antivirus software may flag PyInstaller-created executables as potentially unwanted programs. This is a common false positive. You may need to add an exception in your antivirus software or use the Python script directly.

## Usage Instructions

1. **Encryption Tab**:
   - Select a folder to encrypt
   - Enter a strong password
   - Choose whether to delete the original folder after encryption
   - Click "Encrypt Folder"

2. **7z Protection Tab**:
   - Select a folder to protect
   - Enter a password for the 7z archive
   - Choose compression level
   - Click "Create Protected Archive"

## Security Notes

- Always use strong, unique passwords
- Keep your encryption passwords safe - if lost, encrypted data cannot be recovered
- The application does not store your passwords anywhere 